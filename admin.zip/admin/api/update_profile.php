<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

// Assuming you have established a database connection and assigned it to $conn variable

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $newEmail = $_POST['email'];
    $newPassword = $_POST['password'];
    $userId = $_POST['userId']; // Assuming you have userId available
    $userId=4;

    $updateQuery = "UPDATE tbl_users SET email = '$newEmail', password = '$newPassword' WHERE id = $userId";
    mysqli_query($conn, $updateQuery);

    // Check if the update was successful
    if (mysqli_affected_rows($conn) > 0) {
        $response = array('status' => 'success', 'message' => 'User information updated successfully.');
    } else {
        $response = array('status' => 'error', 'message' => 'Failed to update user information.');
    }

    echo json_encode($response);
    exit;
}

?>