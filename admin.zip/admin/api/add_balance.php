<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

// If form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bill_no = $_POST['billno'];
    $bill_date = $_POST['billdate'];
    $customer_name = $_POST['customername'];
    $total_amount = $_POST['totalamount'];
    $paid_amount = $_POST['paidamount'];
    $pending_amount = $_POST['pendingamount'];
    $returned_amount = $_POST['returnedamount'];
  
    // Insert data into table
    $sql = "INSERT INTO tbl_balance (bill_no, bill_date, customer_name, total_amount, paid_amount, pending_amount, returned_amount) VALUES ('$bill_no', '$bill_date', '$customer_name', '$total_amount', '$paid_amount', '$pending_amount', '$returned_amount')";
  
    if (mysqli_query($conn, $sql)) {
      $success_message = "Data inserted successfully";
    } else {
      $error_message = "Error inserting data: " . mysqli_error($conn);
    }
  
    // Close connection
    mysqli_close($conn);
  }
?>