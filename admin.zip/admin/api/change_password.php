<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php');
$success_message =""; $error_message = "";
$userId =4;
if($_POST['email'])
{
  $newEmail = $_POST['email'];
  $newPassword = $_POST['password'];

  $updateQuery = "UPDATE tbl_users SET email = '$newEmail', password = '$newPassword' WHERE id = $userId";
  mysqli_query($conn, $updateQuery);

  // Check if the update was successful
  if (mysqli_affected_rows($conn) > 0) {
      // echo "User information updated successfully.";
  } else {
      // echo "Failed to update user information.";
  }
}
$selectQuery = "SELECT email FROM tbl_users WHERE id = $userId";
$result = mysqli_query($conn, $selectQuery);

if (mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
}
?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <!-- <h1 class="h3 mb-2 text-gray-800">Customers</h1>  -->
                    <!-- <div class="row"> <div class="col-sm-9"> </div> <div class="col-sm-3" style="padding-left: 130px;"><a href="add_customer.html" class="btn btn-primary " > Add new </a> </div> </div> -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Update Profile </h6>
                            <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                        <form method="POST" action="">
                          <div class="form-group">
                              <label for="email">Email:</label>
                              <input type="email" class="form-control" id="email" name="email" placeholder="Enter new email" value="<?php echo $userData['email']; ?>">
                          </div>
                          <div class="form-group">
                              <label for="password">Password:</label>
                              <input type="text" class="form-control" id="password" name="password" placeholder="Enter new password" value="<?php echo $userData['password']; ?>">
                          </div>
                          <button type="submit" class="btn btn-primary">Update</button>
                      </form>
                              
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>