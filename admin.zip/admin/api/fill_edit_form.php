<?php
// Set CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

 include("../includes/db_code.php");
$id =$_GET['id'];
// Fetch the customer information from the database
$query = "SELECT * FROM tbl_customer WHERE id = '$id'"; // Replace '1' with the appropriate customer ID
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
    // Retrieve the customer data
    $customer = mysqli_fetch_assoc($result);
    
    // Prepare the response data
    $response = array('success' => true, 'customer' => $customer);
    echo json_encode($response);
} else {
    $response = array('success' => false, 'message' => 'Error fetching customer information.');
    echo json_encode($response);
}

// Close the database conn
mysqli_close($conn);
?>
