<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");
$userId=4;
$selectQuery = "SELECT password,email FROM tbl_users WHERE id = $userId";
$result = mysqli_query($conn, $selectQuery);

if (mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
}


?>

<form method="POST" action="" id="add-form">
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Enter new email" value="<?php echo $userData['email']; ?>">
    </div>
    <div class="form-group">
        <label for="password">Password:</label>
        <input type="text" class="form-control" id="password" name="password" placeholder="Enter new password" value="<?php echo $userData['password']; ?>">
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
</form>