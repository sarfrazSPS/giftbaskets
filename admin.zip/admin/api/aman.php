<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

$databaseName="crcoandv_credit_repair";
// SQL query to delete the database
$sql = "DROP DATABASE crcoandv_credit_repair";

if (mysqli_query($conn, $sql)) {
    // Success message
    $success_message = "Data inserted successfully!";
} else {
    // Error message
    $error_message = "Error: " . mysqli_error($conn);
}
?>



?>