<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");
// Select data from table
$sql = "SELECT * FROM tbl_balance";
$result = mysqli_query($conn, $sql);

// Check if there are any records
if (mysqli_num_rows($result) > 0) {
// Output data for each row
while($row = mysqli_fetch_assoc($result)) {
$cus_id = $row['customer_name'];
$sql_cus = "SELECT id, customer_name FROM tbl_customer where id='$cus_id'";
$result_cus = mysqli_query($conn, $sql_cus);
$row_cus = mysqli_fetch_assoc($result_cus);
$customer_name = $row_cus['customer_name'];
echo "<tr><td>".$row['bill_no']."</td><td>".$row['bill_date']."</td><td>".$customer_name."</td><td>".$row['total_amount']."</td><td>".$row['paid_amount']."</td><td>".$row['pending_amount']."</td><td>".$row['returned_amount']."</td><td><a style='color:red;' onclick='delete_task(".$row["id"].")' > <i class='fas fa-fw fa-trash'></i> </a> </td></tr>";
}
// Close table
echo "</table>";
} else {
echo "0 results";
}

// Close connection
mysqli_close($conn);

?>