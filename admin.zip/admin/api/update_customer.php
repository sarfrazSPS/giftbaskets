<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");
// Retrieve the form data
$customerName = $_POST['customer-name'];
// $profilePic = $_FILES['profile-pic']['name'];
$id = $_POST['id'];
$price = $_POST['price'];
$totalAccounts = $_POST['total-accounts'];
$amountPaid = $_POST['amount-paid'];
$workStartedDate = $_POST['work-started-date'];
$workCompletedDate = $_POST['work-completed-date'];
$totalInquiries = $_POST['total-inquiries'];
$phoneNumber = $_POST['phone-no'];


// Prepare the SQL statement
$query = "UPDATE tbl_customer SET 
            customer_name = '$customerName',
            price = '$price',
            total_accounts_needed = '$totalAccounts',
            amount_paid = '$amountPaid',
            work_started_date = '$workStartedDate',
            work_completed_date = '$workCompletedDate',
            total_inquiries_needed = '$totalInquiries',
            phone_number = '$phoneNumber'
          WHERE id = '$id'"; // Replace '1' with the appropriate customer ID

// Execute the query
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
    $response = array('success' => true);
    echo json_encode($response);
} else {
    $response = array('success' => false, 'message' => 'Error updating customer information.');
    echo json_encode($response);
}

// Close the database
?>