<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");
$sql_check = "SELECT * FROM tbl_acc_inq "; // Replace 1 with the id of the record you want to check
$result_check = mysqli_query($conn, $sql_check);
if (mysqli_num_rows($result_check) > 0) {
    $row = mysqli_fetch_assoc($result_check);
}
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $negative_accounts = $_POST["negative-accounts"];
    $inquiries = $_POST["inquiries"];
  
    // Check if the record already exists based on the id column

  
    // If the record exists, update it. Otherwise, insert a new record.
    if (mysqli_num_rows($result_check) > 0) {
      $sql_update = "UPDATE tbl_acc_inq SET negative_accounts = '$negative_accounts', inquiries = '$inquiries' WHERE id = 1"; // Replace 1 with the id of the record you want to update
      if (mysqli_query($conn, $sql_update)) {
        $success_message = "Data updated successfully!";
      } else {
        $error_message = "Error updating data: " . mysqli_error($conn);
      }
    } else {
      $sql_insert = "INSERT INTO tbl_acc_inq (negative_accounts, inquiries) VALUES ('$negative_accounts', '$inquiries')";
      if (mysqli_query($conn, $sql_insert)) {
        $success_message = "Data inserted successfully!";
      } else {
        $error_message = "Error inserting data: " . mysqli_error($conn);
      }
    }
  }
  ?>