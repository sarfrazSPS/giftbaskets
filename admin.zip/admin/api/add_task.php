<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the form data
    $customer_id = mysqli_real_escape_string($conn, $_POST['customer_id']);
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $task = mysqli_real_escape_string($conn, $_POST['task']);
    $date_assigned = mysqli_real_escape_string($conn, $_POST['date_assigned']);

    // Insert the data into the database
    $sql = "INSERT INTO tbl_tasks (customer_id, title, task, date_assigned) 
    VALUES ('$customer_id', '$title', '$task', '$date_assigned')";
    if (mysqli_query($conn, $sql)) {
        // Success message
        $success_message = "Data inserted successfully!";
    } else {
        // Error message
        $error_message = "Error: " . mysqli_error($conn);
    }



}
?>