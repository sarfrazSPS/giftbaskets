<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");
// Prepare the query
$sql = "SELECT * FROM tbl_customer";
$result = mysqli_query($conn, $sql);
// Create an empty variable to store the table rows
$tableRows = "";
// Check if any data is returned
if (mysqli_num_rows($result) > 0) {
    // Loop through the data and add it to the table rows
    while ($row = mysqli_fetch_assoc($result)) {
        if ($row["work_status"] == 1) {
            $src = "img/green_check.png";
        } else {
            $src = "img/grey_check.png";
        }

        // Build the table row
        $tableRows .= "<tr>";
        $tableRows .= "<td><img title='Change Status' style='cursor: pointer !important;' id='check_mark".$row["id"]."' onclick='change_payment_status(".$row["id"].")' src='".$src."' width='130%' /></td>";
        $tableRows .= "<td><a href='customer-profile.html?id=".$row["id"]."'>".$row["customer_name"]."</a></td>";
        if($row["profile_pic"]!="")
        {
            $tableRows .= "<td><img src='uploads/profile-pics/".$row["profile_pic"]."' alt='Profile Picture' width='50' /></td>";

        }
        else
        {
            $tableRows .= "<td></td>";
        }
       
        $tableRows .= "<td>".$row["price"]."</td>";
        $tableRows .= "<td>".$row["total_accounts_needed"]."</td>";
        $tableRows .= "<td>".$row["amount_paid"]."</td>";
        $tableRows .= "<td>".$row["work_started_date"]."</td>";
        $tableRows .= "<td>".$row["work_completed_date"]."</td>";
        $tableRows .= "<td>".$row["total_inquiries_needed"]."</td>";
        $tableRows .= "<td>".$row["phone_number"]."</td>";
        if($row["upload_contract"]!="")
        {
            $tableRows .= "<td><a href='uploads/contracts/".$row["upload_contract"]."'>Download Contract</a></td>";

        }
        else
        {
            $tableRows .= "<td></td>";
        }
       
        $tableRows .= "<td><span class='label label-success'>Active</span></td>";
        $tableRows .= "<td><a style='color:red;' onclick='delete_customer(".$row["id"].")' ><i class='fas fa-fw fa-trash'></i></a> <a href='edit_customer.html?id=".$row["id"]."'> <i class='fas fa-fw fa-edit'></i> </a></td>";
        $tableRows .= "</tr>";
    }
}

// Close the database connection
mysqli_close($conn);

// Return the table rows
echo $tableRows;
?>
