<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

if(isset($_POST['value']))
{
    $value= $_POST['value'];

    $sql_check = "SELECT * FROM tbl_customer  where 	customer_name like '$value%' or phone_number like '$value' "; // Replace 1 with the id of the record you want to check
    $result_check = mysqli_query($conn, $sql_check);
    if (mysqli_num_rows($result_check) > 0) {
        $row = mysqli_fetch_assoc($result_check);
        $id = $row['id'];
    }
    else
    {
        $id = 0;
    }

}
else
{
    $id = $_GET['id'];
}

 $sql_check = "SELECT * FROM tbl_customer  where id='$id'"; // Replace 1 with the id of the record you want to check
$result_check = mysqli_query($conn, $sql_check);
if (mysqli_num_rows($result_check) > 0) {
    $row = mysqli_fetch_assoc($result_check);
}

?>

<div class="row">
                    <div class="col-sm-6">
                        
                        <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <!-- <label for="profile-pic">Profile Picture:</label> -->
                                    <img src='uploads/profile-pics/<?=$row["profile_pic"]?>' alt="Profile Picture" width="50%" class="img-fluid">
                                </div>
                            </div>
                        </div>
<?php 
                        // Populate the HTML fields with the retrieved data
echo '<div class="row">';
echo '  <div class="col-md-4">';
echo '    <div class="form-group">';
echo '      <label for="customer-name">Customer Name:</label>';
echo '      <p id="customer-name">' . $row['customer_name'] . '</p>';
echo '    </div>';
echo '    <div class="form-group">';
echo '      <label for="price">Price:</label>';
echo '      <p id="price">$' . $row['price'] . '</p>';
echo '    </div>';
echo '    <div class="form-group">';
echo '      <label for="total-accounts">Total Accounts Needed to Remove:</label>';
echo '      <p id="total-accounts">' . $row['total_accounts'] . '</p>';
echo '    </div>';
echo '    <div class="form-group">';
echo '      <label for="paid">Amount Paid <i class="fas fa-plus" style="cursor: pointer; color: #858796;" title="Add amount" data-toggle="modal" data-target="#myModal"></i> </label>';
echo '      <table class="table">';
echo '        <tr><td>' . $row['work_started_date'] . '</td><td>$' . $row['amount_paid'] . '</td></tr>';
            $sql_check = "SELECT * FROM tbl_cus_amount_paid   where customer_id='$id'"; // Replace 1 with the id of the record you want to check
            $result_check = mysqli_query($conn, $sql_check);
            if (mysqli_num_rows($result_check) > 0) {
                
                while($row_amount = mysqli_fetch_assoc($result_check))
                {
                    echo '        <tr><td>' . $row_amount['paid_date'] . '</td><td>$' . $row_amount['amount'] . '</td></tr>';
                }
            }
echo '      </table>';
echo '    </div>';
echo '  </div>';
echo '  <div class="col-md-4">';
echo '    <div class="form-group">';
echo '      <label for="work-started-date">Work Started Date:</label>';
echo '      <p id="work-started-date">' . $row['work_started_date'] . '</p>';
echo '    </div>';
echo '    <div class="form-group">';
echo '      <label for="work-completed-date">Work Completed Date:</label>';
echo '      <p id="work-completed-date">' . $row['work_completed_date'] . '</p>';
echo '    </div>';
echo '    <div class="form-group">';
echo '      <label for="total-inquiries">Total Inquiries Needed to Remove:</label>';
echo '      <p id="total-inquiries">' . $row['total_inquiries'] . '</p>';
echo '    </div>';
echo '    <div class="form-group">';
echo '      <label for="phone-no">Phone Number:</label>';
echo '      <p id="phone-no">' . $row['phone_no'] . '</p>';
?>
                            </div>
                            <div class="form-group">
                              <label for="upload-contract">Contract:</label>
                              <a href='uploads/contracts/"<?=$row["upload_contract"]?>'> Download Contract</a>
                              <!-- <a href="contract.pdf" download>Download Contract</a> -->
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <form id="comment_form"  method="post">
                            <div class="form-group">
                            <label for="phone-no">Comments :</label>
                            <textarea class="form-control" id="comment" name="comment" rows="3" > <?=$row['comment'] ?></textarea>
                            </div>
                            <div class="form-group">
                            <!-- <button type="submit" class="btn btn-primary">Save</button> -->
                            <input type="button" class="btn btn-primary" onclick="update_comment()" value="Save" />
                            
                            </div>
                        </form>


                      </div>
                      </div>