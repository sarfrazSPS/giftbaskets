<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

if(isset($_POST['comment']))
{
  $id = $_POST['id'];
  $comment = $_POST['comment'];
  $sql_update = "UPDATE tbl_customer SET comment = '$comment' WHERE id = '$id'"; // Replace 1 with the id of the record you want to update
  mysqli_query($conn, $sql_update);
}

?>