<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

if(isset($_GET['balance_id']))
{
  $balance_id = $_GET['balance_id'];
  // SQL query to delete a record
  $sql = "DELETE FROM tbl_balance WHERE id = '$balance_id'";

  if (mysqli_query($conn, $sql)) {
      $success_message = "Record deleted successfully";
  } else {
      $error_message = "Error deleting record: " . mysqli_error($conn);
  }
  
}

?>