<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");
if(isset($_POST['amount_paid']))
{
    // Get form data
    $date = $_POST['date'];
    $amount_paid = $_POST['amount_paid'];
    $customer_id = $_GET['id'];

    // Insert data into tbl_cus_amount_paid
    $sql = "INSERT INTO tbl_cus_amount_paid (paid_date, amount, customer_id) VALUES ('$date', '$amount_paid', '$customer_id')";

    if (mysqli_query($conn,$sql)) {
        $success_message = "Data inserted successfully";
    } 
    else 
    {
        $error_message = "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
