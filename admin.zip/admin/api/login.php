<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization");
  // Import the database connection code
  include("../includes/db_code.php");

  // Get the email and password from the request body
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Sanitize user input to prevent SQL injection attacks
  $email = mysqli_real_escape_string($conn, $email);
  $password = mysqli_real_escape_string($conn, $password);

  // Query the database for a user with the given email and password
  $query = "SELECT * FROM tbl_users WHERE email='$email' AND password='$password'";
  $result = mysqli_query($conn, $query);

  // Check if a user was found
  if (mysqli_num_rows($result) == 1) {
    // Start a new session and set the user's email as a session variable
    session_start();
    $new_user = mysqli_fetch_assoc($result);
    $data['email'] = $email;
    $data['name'] = $new_user['name'];

    // Return a JSON response indicating success
    $response = array('success' => true, 'message' => 'Login successful.','data' => $data);
    header('Content-Type: application/json');
    echo json_encode($response);
  } else {
    // Return a JSON response indicating failure
    $response = array('success' => false, 'message' => 'Invalid email or password.');
    header('Content-Type: application/json');
    echo json_encode($response);
  }
?>
