<?php
// Set CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

 include("../includes/db_code.php");

function processFormData($conn, $customerName, $profilePic, $price, $totalAccounts, $amountPaid, $workStartedDate, $workCompletedDate, $totalInquiries, $phoneNo, $uploadContract)
{
    // Set the target directories
    $profilePicTargetDir = "../uploads/profile-pics/";
    $uploadContractTargetDir = "../uploads/contracts/";

    // Set the target file paths
   echo  $profilePicTargetFilePath = $profilePicTargetDir . basename($profilePic['name']);
   echo $uploadContractTargetFilePath = $uploadContractTargetDir . basename($uploadContract['name']);
   if($profilePic['name'] !="")
   {
        // Upload the profile picture and the contract file
        if (move_uploaded_file($profilePic["tmp_name"], $profilePicTargetFilePath) && move_uploaded_file($uploadContract["tmp_name"], $uploadContractTargetFilePath)) {
            $profile_pic = $profilePic['name'];
            $upload_contract= $uploadContract['name'];
    
            // Insert the data into the database
            $sql = "INSERT INTO tbl_customer (customer_name, profile_pic, price, total_accounts_needed, amount_paid, work_started_date, work_completed_date, total_inquiries_needed, phone_number, upload_contract) VALUES ('$customerName', '$profile_pic', '$price', '$totalAccounts', '$amountPaid', '$workStartedDate', '$workCompletedDate', '$totalInquiries', '$phoneNo', '$upload_contract')";
    
            // Replace $conn with your database connection variable
    
            if (mysqli_query($conn, $sql)) {
                // Success message
                return "Data inserted successfully!";
            } else {
                // Error message
                return "Error: " . mysqli_error($conn);
            }
    
        } else {
            // Error message
            return "Error uploading files!";
        }

   }
   else
   {
             // Insert the data into the database
             $sql = "INSERT INTO tbl_customer (customer_name, profile_pic, price, total_accounts_needed, amount_paid, work_started_date, work_completed_date, total_inquiries_needed, phone_number, upload_contract) VALUES ('$customerName', '', '$price', '$totalAccounts', '$amountPaid', '$workStartedDate', '$workCompletedDate', '$totalInquiries', '$phoneNo', '')";
    
             // Replace $conn with your database connection variable
     
             if (mysqli_query($conn, $sql)) {
                 // Success message
                 return "Data inserted successfully!";
             } else {
                 // Error message
                 return "Error: " . mysqli_error($conn);
             }

   }

}

// Usage example:
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = $_POST["customer-name"];
    $profilePic = $_FILES["profile-pic"];
    $price = $_POST["price"];
    $totalAccounts = $_POST["total-accounts"];
    $amountPaid = $_POST["amount-paid"];
    $workStartedDate = $_POST["work-started-date"];
    $workCompletedDate = $_POST["work-completed-date"];
    $totalInquiries = $_POST["total-inquiries"];
    $phoneNo = $_POST["phone-no"];
    $uploadContract = $_FILES["upload-contract"];

    $result = processFormData($conn,$customerName, $profilePic, $price, $totalAccounts, $amountPaid, $workStartedDate, $workCompletedDate, $totalInquiries, $phoneNo, $uploadContract);
    echo $result;
}
?>
