<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

// Fetch data from the tbl_customer table
  $sql = "SELECT * FROM tbl_tasks";
  $result = mysqli_query($conn, $sql);

  // Check if any data is returned
  if (mysqli_num_rows($result) > 0) {

  // Loop through the data and display it in the HTML table
  while($row = mysqli_fetch_assoc($result)) {
    $cus_id = $row['customer_id'];
    $sql_cus = "SELECT id, customer_name FROM tbl_customer where id='$cus_id'";
    $result_cus = mysqli_query($conn, $sql_cus);
    $row_cus = mysqli_fetch_assoc($result_cus);
    $customer_name = $row_cus['customer_name'];
      if($row["status"] == 1)
      {
          
          $src= "img/green_check.png";

      }
      else
      {
          $src= "img/grey_check.png";
      }
      // echo "<tr><td> <img title='Change Status' style='cursor: pointer !important;' id='check_mark".$row["id"]."' onclick='change_payment_status(".$row["id"].")' src='".$src."' width='80%' /> </td><td> <a href='customer-profile.php?id=".$row["id"]."'> ".$row["customer_name"]." </a> </td><td><img src='uploads/profile-pics/".$row["profile_pic"]."' alt='Profile Picture' width='50' /></td><td>".$row["price"]."</td><td>".$row["total_accounts_needed"]."</td><td>".$row["amount_paid"]."</td><td>".$row["work_started_date"]."</td><td>".$row["work_completed_date"]."</td><td>".$row["total_inquiries_needed"]."</td><td>".$row["phone_number"]."</td><td> <a href='uploads/contracts/".$row["upload_contract"]."'> Download Contract</a></td><td><span class='label label-success'> Active </span></td><td><a style='color:red;' onclick='return confirm(\"Are you sure you want to delete this record? \")' href='customer.php?customer_id=".$row["id"]."' > <i class='fas fa-fw fa-trash'></i> </a> </td></tr>";
  
      echo "<tr>
      
      <td> <img title='Change Status' style='cursor: pointer !important;' id='check_mark".$row["id"]."' onclick='change_payment_status(".$row["id"].")' src='".$src."' width='50%' /> </td>
      <td>" . $row["title"] . "</td>
      <td>" . $customer_name. "</td>
      
      <td>" . $row["task"] . "</td>
      <td>" . $row["date_assigned"] . "</td>
      <td><a style='color:red;' onclick='delete_task(".$row["id"].")' > <i class='fas fa-fw fa-trash'></i> </a> </td>
    </tr>";

   }
  
  } else {
  echo "No data found.";
  }

  // Close connection
  mysqli_close($conn);
  
?>