<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization");
include("../includes/db_code.php");

    $sql = "SELECT id, customer_name FROM tbl_customer";
    $result = mysqli_query($conn, $sql);
    echo '<label for="customer_id">Customer Name:</label>';
    echo "<select name='customer_id' class='form-control' >";
    while ($row = mysqli_fetch_assoc($result)) 
    {
        echo "<option value='". $row['id'] ."'>" . $row['customer_name'] . "</option>";
    }
    echo "</select>";
?>