<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
include("../includes/db_code.php");

// Check if the form has been submitted
if(isset($_GET['task_id']))
{
  $task_id = $_GET['task_id'];
  // SQL query to delete a record
  $sql = "DELETE FROM tbl_tasks WHERE id = '$task_id'";

  if (mysqli_query($conn, $sql)) {
      $success_message = "Record deleted successfully";
  } else {
      $error_message = "Error deleting record: " . mysqli_error($conn);
  }
  
}
?>