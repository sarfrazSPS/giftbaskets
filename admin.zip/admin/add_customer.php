<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php');
$success_message =""; $error_message = "";
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the form data
    $customerName = $_POST["customer-name"];
    $profilePic = $_FILES["profile-pic"]["name"];
    $price = $_POST["price"];
    $totalAccounts = $_POST["total-accounts"];
    $amountPaid = $_POST["amount-paid"];
    $workStartedDate = $_POST["work-started-date"];
    $workCompletedDate = $_POST["work-completed-date"];
    $totalInquiries = $_POST["total-inquiries"];
    $phoneNo = $_POST["phone-no"];
    $uploadContract = $_FILES["upload-contract"]["name"];

    // Set the target directories
    $profilePicTargetDir = "uploads/profile-pics/";
    $uploadContractTargetDir = "uploads/contracts/";

    // Set the target file paths
    $profilePicTargetFilePath = $profilePicTargetDir . basename($profilePic);
    $uploadContractTargetFilePath = $uploadContractTargetDir . basename($uploadContract);

    if($profilePic = $_FILES["profile-pic"]["name"] !="")
    {
          // Upload the profile picture and the contract file
          if (move_uploaded_file($_FILES["profile-pic"]["tmp_name"], $profilePicTargetFilePath) && move_uploaded_file($_FILES["upload-contract"]["tmp_name"], $uploadContractTargetFilePath)) {

            // Insert the data into the database
            $sql = "INSERT INTO tbl_customer (customer_name, profile_pic, price, total_accounts_needed,amount_paid, work_started_date, work_completed_date, total_inquiries_needed, phone_number, upload_contract) VALUES ('$customerName', '$profilePic', '$price', '$totalAccounts', '$amountPaid', '$workStartedDate', '$workCompletedDate', '$totalInquiries', '$phoneNo', '$uploadContract')";
            if (mysqli_query($conn, $sql)) {
                // Success message
                $success_message = "Data inserted successfully!";
            } else {
                // Error message
                $error_message = "Error: " . mysqli_error($conn);
            }

        } else {
            // Error message
            $error_message = "Error uploading files!";
        }

    }
    else
    {
      $sql = "INSERT INTO tbl_customer (customer_name, profile_pic, price, total_accounts_needed,amount_paid, work_started_date, work_completed_date, total_inquiries_needed, phone_number, upload_contract) VALUES ('$customerName', '', '$price', '$totalAccounts', '$amountPaid', '$workStartedDate', '$workCompletedDate', '$totalInquiries', '$phoneNo', '')";
      if (mysqli_query($conn, $sql)) {
          // Success message
          $success_message = "Data inserted successfully!";
      } else {
          // Error message
          $error_message = "Error: " . mysqli_error($conn);
      }

    }


}

?>


                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Add Customer</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Add Customer</h6>
                            <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                  <label for="customer-name">Customer Name:</label>
                                  <input type="text" class="form-control" name="customer-name" placeholder="Enter customer name">
                                </div>
                                <div class="form-group">
                                  <label for="profile-pic">Profile Picture:</label>
                                  <input type="file" class="form-control-file" name="profile-pic">
                                </div>
                                <div class="form-group">
                                  <label for="price">Price:</label>
                                  <input type="number" class="form-control" name="price" placeholder="Enter price">
                                </div>
                                <div class="form-group">
                                  <label for="total-accounts">Total Accounts Needed to Remove:</label>
                                  <input type="number" class="form-control" name="total-accounts" placeholder="Enter total accounts">
                                </div>

                                <div class="form-group">
                                    <label for="amount-paid">Amount Paid:</label>
                                    <input type="number" class="form-control" name="amount-paid" placeholder="Enter amount paid">
                                </div>
                                <div class="form-group">
                                  <label for="work-started-date">Work Started Date:</label>
                                  <input type="date" class="form-control" name="work-started-date">
                                </div>
                                <div class="form-group">
                                  <label for="work-completed-date">Work Completed Date:</label>
                                  <input type="date" class="form-control" name="work-completed-date">
                                </div>
                                <div class="form-group">
                                  <label for="total-inquiries">Total Inquiries Needed to Remove:</label>
                                  <input type="number" class="form-control" name="total-inquiries" placeholder="Enter total inquiries">
                                </div>
                                <div class="form-group">
                                  <label for="phone-no">Phone Number:</label>
                                  <input type="tel" class="form-control" name="phone-no" placeholder="Enter phone number">
                                </div>
                                <div class="form-group">
                                  <label for="upload-contract">Upload Contract:</label>
                                  <input type="file" class="form-control-file" name="upload-contract">
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                              </form>
                              
 
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>