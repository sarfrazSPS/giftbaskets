<?php
error_reporting(1);
// Connect to the database
$conn = mysqli_connect("localhost", "marketin_corporate", "Corporate23%", "marketin_pa_dutch_basket");

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


?>
