<?php
error_reporting(1);
// Connect to the database
$conn = mysqli_connect("localhost", "marketin_corporate", "Corporate23%", "marketin_pa_dutch_basket");

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
  echo "failed etstetettsetetetettetetetetetestestsetsetsettsetestetetestetestse";
}
else
{
   echo "Success etstetettsetetetettetetetetetestestsetsetsettsetestetetestetestse";
}


$sql ="CREATE TABLE tbl_users (id INT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL )";
$result = mysqli_query($conn, $sql);

echo mysqli_error($conn);

$email = "admin@gmail.com";
$password ="Corporate23%" ; // Hash the password
$name = "Adminr";

$sql = "INSERT INTO tbl_users (email, password, name) VALUES ('$email', '$password', '$name')";

$result = mysqli_query($conn, $sql);

echo mysqli_error($conn);



$sql ="CREATE TABLE tbl_promocode (id INT AUTO_INCREMENT PRIMARY KEY, promocode VARCHAR(255) NOT NULL, expir_date DATE NOT NULL)";

?>
