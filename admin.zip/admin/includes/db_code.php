<?php
error_reporting(1);
// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "db_pa_dutch_baskets");

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>