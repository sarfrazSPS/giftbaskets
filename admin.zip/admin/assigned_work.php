<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php');
$success_message =""; $error_message = "";
// Check if the form has been submitted
if(isset($_GET['task_id']))
{
  $task_id = $_GET['task_id'];
  // SQL query to delete a record
  $sql = "DELETE FROM tbl_promocode WHERE id = '$task_id'";

  if (mysqli_query($conn, $sql)) {
      $success_message = "Record deleted successfully";
  } else {
      $error_message = "Error deleting record: " . mysqli_error($conn);
  }
  
}
?>


                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Promo Codes </h1>
                        <a href="add_task.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-plus fa-sm text-white-50"></i> Promo Codes</a>
                    </div>

                    <!-- Page Heading -->
                    <!-- <h1 class="h3 mb-2 text-gray-800"></h1> 
                    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
                    <!-- <div class="row"> <div class="col-sm-9"> </div> <div class="col-sm-3" style="padding-left: 130px;"><a href="add_customer.html" class="btn btn-primary " > Add new </a> </div> </div> -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Promo Codes List</h6>
                            <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                      <tr>
                                        <th>Promo Code</th>

                                        <th>Expiry Date</th>
                                        <th>Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>

                                      <?php
                                      // Fetch data from the tbl_customer table
                                        $sql = "SELECT * FROM tbl_promocode";
                                        $result = mysqli_query($conn, $sql);

                                        // Check if any data is returned
                                        if (mysqli_num_rows($result) > 0) {

                                        // Loop through the data and display it in the HTML table
                                        while($row = mysqli_fetch_assoc($result)) {


                                            // echo "<tr><td> <img title='Change Status' style='cursor: pointer !important;' id='check_mark".$row["id"]."' onclick='change_payment_status(".$row["id"].")' src='".$src."' width='80%' /> </td><td> <a href='customer-profile.php?id=".$row["id"]."'> ".$row["customer_name"]." </a> </td><td><img src='uploads/profile-pics/".$row["profile_pic"]."' alt='Profile Picture' width='50' /></td><td>".$row["price"]."</td><td>".$row["total_accounts_needed"]."</td><td>".$row["amount_paid"]."</td><td>".$row["work_started_date"]."</td><td>".$row["work_completed_date"]."</td><td>".$row["total_inquiries_needed"]."</td><td>".$row["phone_number"]."</td><td> <a href='uploads/contracts/".$row["upload_contract"]."'> Download Contract</a></td><td><span class='label label-success'> Active </span></td><td><a style='color:red;' onclick='return confirm(\"Are you sure you want to delete this record? \")' href='customer.php?customer_id=".$row["id"]."' > <i class='fas fa-fw fa-trash'></i> </a> </td></tr>";
                                        
                                            echo "<tr>
                                            
                                            <td>" . $row["promocode"] . "</td>

                                            <td>" . $row["expir_date"] . "</td>
                                            <td><a style='color:red;' onclick='return confirm(\"Are you sure you want to delete this record? \")' href='assigned_work.php?task_id=".$row["id"]."' > <i class='fas fa-fw fa-trash'></i> </a> </td>
                                          </tr>";

                                         }
                                        
                                        } else {
                                        echo "No data found.";
                                        }

                                        // Close connection
                                        mysqli_close($conn);
                                        ?>
                                    </tbody>
                                  </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>

<script> 
function change_payment_status(cus_id)
{
    var status = "";
    if ($('#check_mark'+cus_id).attr('src') === 'img/grey_check.png') 
    {
      $('#check_mark'+cus_id).attr('src', 'img/green_check.png');
      status =1;
    }
    else
    {
        $('#check_mark'+cus_id).attr('src', 'img/grey_check.png');
        status=0;
    }

    $.ajax({
      url: 'task_status.php',
      type: 'POST',
      data: {customer_id: cus_id,status:status},
      success: function(response) {
        // Update work_status on the page
        // if (response === 'Work status updated successfully') {
        //   $('#work-status').text('Working');
        // } else {
        //   alert(response);
        // }
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Handle error
        // alert('Error updating work status: ' + textStatus + ' - ' + errorThrown);
      }
    });



}
</script>