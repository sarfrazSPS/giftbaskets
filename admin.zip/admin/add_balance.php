<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php'); 
$success_message =""; $error_message = "";
// If form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $bill_no = $_POST['billno'];
  $bill_date = $_POST['billdate'];
  $customer_name = $_POST['customername'];
  $total_amount = $_POST['totalamount'];
  $paid_amount = $_POST['paidamount'];
  $pending_amount = $_POST['pendingamount'];
  $returned_amount = $_POST['returnedamount'];

  // Insert data into table
  $sql = "INSERT INTO tbl_balance (bill_no, bill_date, customer_name, total_amount, paid_amount, pending_amount, returned_amount) VALUES ('$bill_no', '$bill_date', '$customer_name', '$total_amount', '$paid_amount', '$pending_amount', '$returned_amount')";

  if (mysqli_query($conn, $sql)) {
    $success_message = "Data inserted successfully";
  } else {
    $error_message = "Error inserting data: " . mysqli_error($conn);
  }

  // Close connection
  mysqli_close($conn);
}

?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Add Customer Balance</h1>
                    <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                    <?php endif; ?>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Add Customer Balance</h6>
                        </div>
                        <div class="card-body">

                            <form method="post" action="">
                                <div class="form-group">
                                  <label for="billno">Bill No:</label>
                                  <input type="text" class="form-control" name="billno" placeholder="Enter Bill No">
                                </div>
                                <div class="form-group">
                                  <label for="billdate">Bill Date:</label>
                                  <input type="date" class="form-control" name="billdate" placeholder="Enter Bill Date">
                                </div>
                                <div class="form-group">
                                  <label for="customername">Customer Name:</label>
                                  <?php
                                  // Query the tbl_customer table
                                    $sql = "SELECT id, customer_name FROM tbl_customer";
                                    $result = mysqli_query($conn, $sql);

                                    // Create the select dropdown
                                    echo "<select name='customername' class='form-control' >";
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<option value='" . $row['id'] . "'>" . $row['customer_name'] . "</option>";
                                    }
                                    echo "</select>";
                                  ?>
                                  <!-- <input type="text" class="form-control" name="customername" placeholder="Enter Customer Name"> -->
                                </div>
                                <div class="form-group">
                                  <label for="totalamount">Total Amount:</label>
                                  <input type="number" class="form-control" name="totalamount" placeholder="Enter Total Amount">
                                </div>
                                <div class="form-group">
                                  <label for="paidamount">Paid Amount:</label>
                                  <input type="number" class="form-control" name="paidamount" placeholder="Enter Paid Amount">
                                </div>
                                <div class="form-group">
                                  <label for="pendingamount">Pending Amount:</label>
                                  <input type="number" class="form-control" name="pendingamount" placeholder="Enter Pending Amount">
                                </div>
                                <div class="form-group">
                                  <label for="returnedamount">Returned Amount:</label>
                                  <input type="number" class="form-control" name="returnedamount" placeholder="Enter Returned Amount">
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                              </form>
                              
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>
