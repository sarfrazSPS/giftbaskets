<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php');
$success_message =""; $error_message = "";

$sql_check = "SELECT * FROM tbl_acc_inq "; // Replace 1 with the id of the record you want to check
$result_check = mysqli_query($conn, $sql_check);
if (mysqli_num_rows($result_check) > 0) {
    $row = mysqli_fetch_assoc($result_check);
}
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $negative_accounts = $_POST["negative-accounts"];
    $inquiries = $_POST["inquiries"];
  
    // Check if the record already exists based on the id column

  
    // If the record exists, update it. Otherwise, insert a new record.
    if (mysqli_num_rows($result_check) > 0) {
      $sql_update = "UPDATE tbl_acc_inq SET negative_accounts = '$negative_accounts', inquiries = '$inquiries' WHERE id = 1"; // Replace 1 with the id of the record you want to update
      if (mysqli_query($conn, $sql_update)) {
        $success_message = "Data updated successfully!";
      } else {
        $error_message = "Error updating data: " . mysqli_error($conn);
      }
    } else {
      $sql_insert = "INSERT INTO tbl_acc_inq (negative_accounts, inquiries) VALUES ('$negative_accounts', '$inquiries')";
      if (mysqli_query($conn, $sql_insert)) {
        $success_message = "Data inserted successfully!";
      } else {
        $error_message = "Error inserting data: " . mysqli_error($conn);
      }
    }
  }

$sql_check = "SELECT * FROM tbl_acc_inq "; // Replace 1 with the id of the record you want to check
$result_check = mysqli_query($conn, $sql_check);
if (mysqli_num_rows($result_check) > 0) {
    $row = mysqli_fetch_assoc($result_check);
}
 ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <!-- <h1 class="h3 mb-2 text-gray-800">Customers</h1>  -->
                    <!-- <div class="row"> <div class="col-sm-9"> </div> <div class="col-sm-3" style="padding-left: 130px;"><a href="add_customer.html" class="btn btn-primary " > Add new </a> </div> </div> -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Total Accounts/Inq Removed </h6>
                            <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <form action="" method="post">
                                <div class="form-row">
                                  <div class="col-6">
                                    <div class="form-group">
                                      <label for="textarea1">Negative Accounts</label>
                                      <textarea class="form-control" id="textarea1" name="negative-accounts" rows="3"><?=$row['negative_accounts']?></textarea>
                                    </div>
                                  </div>
                                  <div class="col-6">
                                    <div class="form-group">
                                      <label for="textarea2">Inquiries</label>
                                      <textarea class="form-control" id="textarea2" name="inquiries" rows="3"><?=$row['inquiries']?></textarea>
                                    </div>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                              </form>
                              
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>