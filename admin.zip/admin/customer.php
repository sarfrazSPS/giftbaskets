<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php');
$success_message =""; $error_message = "";
// Check if the form has been submitted
if(isset($_GET['customer_id']))
{
  $customer_id = $_GET['customer_id'];
  // SQL query to delete a record
  $sql = "DELETE FROM tbl_customer WHERE id = '$customer_id'";

  if (mysqli_query($conn, $sql)) {
      $success_message = "Record deleted successfully";
  } else {
      $error_message = "Error deleting record: " . mysqli_error($conn);
  }
  
}
?>


                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Customers </h1>
                        <a href="add_customer.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-plus fa-sm text-white-50"></i> Add Customer</a>
                    </div>

                    <!-- Page Heading -->
                    <!-- <h1 class="h3 mb-2 text-gray-800"></h1> 
                    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
                    <!-- <div class="row"> <div class="col-sm-9"> </div> <div class="col-sm-3" style="padding-left: 130px;"><a href="add_customer.html" class="btn btn-primary " > Add new </a> </div> </div> -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Customers List</h6>
                            <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                      <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Picture</th>
                                        <th>Price</th>
                                        <th>Accounts to Remove</th>
                                        <th>Paid</th>
                                        <th>Work Started Date</th>
                                        <th>Work Completed Date</th>
                                        <th>Inquiries  to Remove</th>
                                        <th>Phone </th>
                                        <th>Contract</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <!-- <tr>
                                        <td><a href="customer-profile.html" style="color:#858796">John Doe</a></td>
                                        <td><img src="profile-pic.jpg" alt="Profile Picture" width="50"></td>
                                        <td>$500</td>
                                        <td>10</td>
                                        <td>Yes</td>
                                        <td>2022-01-01</td>
                                        <td>2022-01-10</td>
                                        <td>20</td>
                                        <td>+1 123-456-7890</td>
                                        <td><a href="contract.pdf" download>Download Contract</a></td>
                                        <td><span class="label label-success">Active </span></td>
                                       
                                      </tr> -->
                                      <?php
                                      // Fetch data from the tbl_customer table
                                        $sql = "SELECT * FROM tbl_customer";
                                        $result = mysqli_query($conn, $sql);

                                        // Check if any data is returned
                                        if (mysqli_num_rows($result) > 0) {

                                        // Loop through the data and display it in the HTML table
                                        while($row = mysqli_fetch_assoc($result)) {
                                            if($row["work_status"] == 1)
                                            {
                                                
                                                $src= "img/green_check.png";

                                            }
                                            else
                                            {
                                                $src= "img/grey_check.png";
                                            }
                                            if($row["profile_pic"] =="")
                                            {
                                              echo "<tr><td> <img title='Change Status' style='cursor: pointer !important;' id='check_mark".$row["id"]."' onclick='change_payment_status(".$row["id"].")' src='".$src."' width='80%' /> </td><td> <a href='customer-profile.php?id=".$row["id"]."'> ".$row["customer_name"]." </a> </td><td>  </td><td>".$row["price"]."</td><td>".$row["total_accounts_needed"]."</td><td>".$row["amount_paid"]."</td><td>".$row["work_started_date"]."</td><td>".$row["work_completed_date"]."</td><td>".$row["total_inquiries_needed"]."</td><td>".$row["phone_number"]."</td><td> </td><td><span class='label label-success'> Active </span></td><td><a style='color:red;' onclick='return confirm(\"Are you sure you want to delete this record? \")' href='customer.php?customer_id=".$row["id"]."' > <i class='fas fa-fw fa-trash'></i> </a> </td></tr>";
                                            }
                                            else
                                            {
                                              echo "<tr><td> <img title='Change Status' style='cursor: pointer !important;' id='check_mark".$row["id"]."' onclick='change_payment_status(".$row["id"].")' src='".$src."' width='80%' /> </td><td> <a href='customer-profile.php?id=".$row["id"]."'> ".$row["customer_name"]." </a> </td><td><img src='uploads/profile-pics/".$row["profile_pic"]."' alt='Profile Picture' width='50' /></td><td>".$row["price"]."</td><td>".$row["total_accounts_needed"]."</td><td>".$row["amount_paid"]."</td><td>".$row["work_started_date"]."</td><td>".$row["work_completed_date"]."</td><td>".$row["total_inquiries_needed"]."</td><td>".$row["phone_number"]."</td><td> <a href='uploads/contracts/".$row["upload_contract"]."'> Download Contract</a></td><td><span class='label label-success'> Active </span></td><td><a style='color:red;' onclick='return confirm(\"Are you sure you want to delete this record? \")' href='customer.php?customer_id=".$row["id"]."' > <i class='fas fa-fw fa-trash'></i> </a> </td></tr>";

                                            }
                                            
                                        }
                                        
                                        } else {
                                        echo "No data found.";
                                        }

                                        // Close connection
                                        mysqli_close($conn);
                                        ?>
                                    </tbody>
                                  </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>

<script> 
function change_payment_status(cus_id)
{
    var status = "";
    if ($('#check_mark'+cus_id).attr('src') === 'img/grey_check.png') 
    {
      $('#check_mark'+cus_id).attr('src', 'img/green_check.png');
      status =1;
    }
    else
    {
        $('#check_mark'+cus_id).attr('src', 'img/grey_check.png');
        status=0;
    }

    $.ajax({
      url: 'update_work_status.php',
      type: 'POST',
      data: {customer_id: cus_id,status:status},
      success: function(response) {
        // Update work_status on the page
        // if (response === 'Work status updated successfully') {
        //   $('#work-status').text('Working');
        // } else {
        //   alert(response);
        // }
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Handle error
        alert('Error updating work status: ' + textStatus + ' - ' + errorThrown);
      }
    });



}
</script>