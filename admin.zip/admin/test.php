<?php
$dsn = "mysql:host=localhost;dbname=db_credit_repair";
$user = "root";
$password = "";

try {
   $pdo = new PDO($dsn, $user, $password);
   echo "PDO connection successful";
} catch (PDOException $e) {
   echo "PDO connection failed: " . $e->getMessage();
}
?>
