<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php');
$success_message =""; $error_message = "";
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the form data
    $promocode = mysqli_real_escape_string($conn, $_POST['promocode']);
    $expiry_date = mysqli_real_escape_string($conn, $_POST['expiry_date']);

    // Insert the data into the database
    echo  $sql = "INSERT INTO tbl_promocode (promocode, expir_date)   VALUES ( '$promocode', '$expiry_date')";
    if (mysqli_query($conn, $sql)) {
        // Success message
        $success_message = "Data inserted successfully!";
    } else {
        // Error message
        $error_message = "Error: " . mysqli_error($conn);
    }
    echo $error_message;



}


$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
$promoCode = '';

for ($i = 0; $i < 20; $i++) {
    $promoCode .= $characters[rand(0, strlen($characters) - 1)];
}
// echo $promoCode;

// return $promoCode;

?>


                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Create Promo Code </h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Create Promo Code</h6>
                            <?php if (!empty($success_message)) : ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <form action="" method="post" enctype="multipart/form-data">

                                <div class="form-group">
                                    <label for="title">Promo Code:</label>
                                    <input type="text" class="form-control" id="promoCode" name="promocode" value="<?=$promoCode?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="title">Discount (%):</label>
                                    <input type="text" class="form-control" id="promoCode" name="discount"  required>
                                </div>

                                <div class="form-group">
                                    <label for="date_assigned">Expiry Date :</label>
                                    <input type="date" class="form-control" id="expiry_date" name="expiry_date" required>
                                </div>

                                <button type="submit" class="btn btn-primary">Submit</button>
                              </form>
                              
 
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>