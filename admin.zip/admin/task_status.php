<?php include("includes/db_code.php"); ?>
<?php
// Get customer ID from AJAX request
$customer_id = $_POST['customer_id'];
$status = $_POST['status'];
// Update payment_status in database

$sql = "UPDATE tbl_tasks SET status = '$status' WHERE id = $customer_id";
if (mysqli_query($conn, $sql) === TRUE) {
  echo "Payment status updated successfully";
} else {
  echo "Error updating payment status: " . $mysqli->error;
}
$mysqli->close();
?>
