<?php 
$info = pathinfo( __FILE__ );
$title = ucwords( $info['filename'] );
include('includes/header.php'); 
$success_message =""; $error_message = "";
// Check if the form has been submitted
if(isset($_GET['balance_id']))
{
  $balance_id = $_GET['balance_id'];
  // SQL query to delete a record
  $sql = "DELETE FROM tbl_balance WHERE id = '$balance_id'";

  if (mysqli_query($conn, $sql)) {
      $success_message = "Record deleted successfully";
  } else {
      $error_message = "Error deleting record: " . mysqli_error($conn);
  }
  
}
?>
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Balance </h1>
                        <a href="add_balance.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-plus fa-sm text-white-50"></i> Add Customer Balance</a>
                    </div>

                    <!-- Page Heading -->
                    <!-- <h1 class="h3 mb-2 text-gray-800">Customers</h1>  -->
                    <!-- <div class="row"> <div class="col-sm-9"> </div> <div class="col-sm-3" style="padding-left: 130px;"><a href="add_customer.html" class="btn btn-primary pull-right " > Add Customer Balance </a> </div> </div> -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Manage Customer Balance</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                      <tr>
                                        <th>Bill no</th>
                                        <th>Bill Date</th>
                                        <th>Customer Name</th>
                                        <th>Total Amount </th>
                                        <th>Paid Amount</th>
                                        <th>Pending Amount</th>
                                        <th>Returned Amount</th>
                                        <!-- <th>Action</th> -->
                                        <th>Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                                                            // Select data from table
                                        $sql = "SELECT * FROM tbl_balance";
                                        $result = mysqli_query($conn, $sql);

                                        // Check if there are any records
                                        if (mysqli_num_rows($result) > 0) {
                                         // Output data for each row
                                        while($row = mysqli_fetch_assoc($result)) {
                                            $cus_id = $row['customer_name'];
                                            $sql_cus = "SELECT id, customer_name FROM tbl_customer where id='$cus_id'";
                                            $result_cus = mysqli_query($conn, $sql_cus);
                                            $row_cus = mysqli_fetch_assoc($result_cus);
                                            $customer_name = $row_cus['customer_name'];
                                            echo "<tr><td>".$row['bill_no']."</td><td>".$row['bill_date']."</td><td>".$customer_name."</td><td>".$row['total_amount']."</td><td>".$row['paid_amount']."</td><td>".$row['pending_amount']."</td><td>".$row['returned_amount']."</td><td><a style='color:red;' onclick='return confirm(\"Are you sure you want to delete this record? \")' href='customer.php?customer_id=".$row["id"]."' > <i class='fas fa-fw fa-trash'></i> </a> </td></tr>";
                                        }
                                        // Close table
                                        echo "</table>";
                                        } else {
                                        echo "0 results";
                                        }

                                        // Close connection
                                        mysqli_close($conn);

                                        ?>
                                      
                                    </tbody>
                                  </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->
<?php include('includes/footer.php'); ?>